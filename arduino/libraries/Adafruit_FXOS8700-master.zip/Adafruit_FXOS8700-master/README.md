# Adafruit_FXOS8700

Driver for the Adafruit FXOS8700 Accelerometer/Magnetometer Breakout
