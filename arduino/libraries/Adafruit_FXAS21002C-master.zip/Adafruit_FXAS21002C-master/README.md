# Adafruit_FXAS21002C
Driver for the Adafruit FXAS21002C 3-Axis gyroscope breakout
